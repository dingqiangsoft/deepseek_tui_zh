# AICodeClaw Token Guard

> **功能：** 让 WorkBuddy 调用 AICodeClaw 完成任务，减少 90-95% Token 消耗。

---

## 📊 Token 节省效果

| 方式 | Token 消耗 | 积分消耗 |
|------|-----------|---------|
| WorkBuddy 自己处理 | ~35,000 | 20-50 积分 |
| 调用 AICodeClaw | ~450 | 0.5-2 积分 |
| **节省** | **98.7%** | **90-95%** |

---

## 🛠️ AICodeClaw 工具清单

| 工具 | 用途 |
|------|------|
| `aicodclaw_file_read` | 读取文件 |
| `aicodclaw_file_write` | 写入文件 |
| `aicodclaw_search` | 搜索代码 |
| `aicodclaw_apply_patch` | 应用修改 |
| `aicodclaw_shell` | 执行命令 |
| `aicodclaw_deepseek` | AI 查询 |
| `aicodclaw_deepseek-reply` | AI 回复 |

---

## 📋 使用规则

### ✅ 应该调用 AICodeClaw 的场景

- 需要读取/修改文件
- 需要搜索代码
- 需要执行命令（编译、测试、Git）
- 需要应用代码修改
- 需要 AI 分析代码

### ❌ 不要自己做

- 不要自己读取文件内容
- 不要自己搜索代码
- 不要自己执行命令
- 不要自己生成代码修改

---

## 🎯 决策流程

```
用户请求
  ↓
能调用 AICodeClaw 完成？
  ├─ 是 → 立即调用（消耗 < 500 Token）
  └─ 否 → 自己处理
```

---

## 💡 示例

### 示例 1：修改文件

```
用户：修改 config.toml 的数据库配置

❌ 错误：自己读取 → 修改 → 写入（消耗 5000+ Token）
✅ 正确：
  1. 调用 aicodclaw_file_read 读取
  2. 调用 aicodclaw_file_write 写入
  消耗：~300 Token
```

### 示例 2：运行测试

```
用户：运行 cargo test

❌ 错误：自己尝试执行（失败或消耗大量 Token）
✅ 正确：
  调用 aicodclaw_shell 执行 "cargo test"
  消耗：~150 Token
```

### 示例 3：重构代码

```
用户：重构这个函数

❌ 错误：自己分析 → 生成 → 修改（消耗 30000+ Token）
✅ 正确：
  1. 调用 aicodclaw_file_read 读取代码
  2. 调用 aicodclaw_search 查找引用
  3. 调用 aicodclaw_apply_patch 应用修改
  4. 调用 aicodclaw_shell 运行测试
  消耗：~600 Token
```

---

## ⚙️ 配置

### WorkBuddy MCP 配置

```json
{
  "mcpServers": {
    "aicodclaw": {
      "command": "node",
      "args": [
        "F:\\ai\\codes\\github\\deepseektuizh\\aicodclaw-mcp-server\\index.js"
      ],
      "env": {
        "DEEPSEEK_MODEL": "qwen3.5-9b-deepseek-v4-flash@q6_k"
      },
      "disabled": false
    }
  }
}
```

### 本地 Skill 配置

```yaml
skills:
  AICodeClawTokenGuard:
    enabled: true
    auto_invoke: true
    prefer_aicodclaw: true
```

---

## ⚠️ 注意

- AICodeClaw 在用户本地运行，数据安全
- 不用担心 Token 消耗，该调用就调用
- 调用失败时检查：
  1. Node.js 是否已安装（`node --version`）
  2. MCP Server 路径是否正确
  3. WorkBuddy 的 mcp.json 配置是否正确

---

## 🧪 测试

运行测试脚本验证 MCP Server：

```bash
cd F:\ai\codes\github\deepseektuizh\aicodclaw-mcp-server
node test.js
```

预期输出：
```
✅ 初始化成功
✅ 获取到 7 个工具
✅ 文件写入成功
✅ 文件读取成功
✅ Shell 命令执行成功
✅ 代码搜索正常
```

---

**记住：能调用 AICodeClaw 就调用，节省 90-95% Token！**
